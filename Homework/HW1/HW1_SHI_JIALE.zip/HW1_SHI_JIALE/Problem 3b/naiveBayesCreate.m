function model = naiveBayesCreate(theta, classPrior)
%% Construct a naive Bayes model

% This file is from pmtk3.googlecode.com


model = structure(theta, classPrior); 
end
