P3 is a 88x3 matrix. Out of the three columns, the first two are the input
and the third is the output/target.

For ploting the iscriminant function, use x = -5:0.1:10 to generate the inputs;